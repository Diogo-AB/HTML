/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
// Importamos as dependências necessárias
import React, { useEffect, useState } from 'react';

const card = (pokemon) => {
  const cardName = `body ${pokemon.types[0].type.name}`
  return (
    <div className={cardName}>
      <div className= "Nome"><h2>{pokemon.name}</h2></div>
      <img src={pokemon.sprites.front_default} alt={pokemon.name} />
      <img src={pokemon.sprites.back_default} alt={pokemon.name} />
      <div>
      <img src={pokemon.sprites.front_shiny} alt={pokemon.name} />
      <img src={pokemon.sprites.back_shiny} alt={pokemon.name} />
      
      <h2>{pokemon.types[0].type.name}</h2>
      </div>    
    </div>
  )
}

// Primeiro, vamos criar o componente PokemonCard
// Este componente recebe um pokemon como prop e exibe o nome e a imagem do pokemon
export default function PokemonCard({ pokemon }) {
  
  return (
    card(pokemon)
  );
}
//<h2>{pokemon.types.map((item) => (item.type.name))}</h2>
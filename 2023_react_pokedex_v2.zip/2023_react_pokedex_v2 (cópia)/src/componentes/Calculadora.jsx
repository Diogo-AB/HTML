import React, {useState} from "react";
export default function Calculadora(){

    const [numero, setCount3] = useState(0)
    const [numeroalternativo, setCount4] = useState(0)
    const [result1, setCount5] = useState(0)
    const [result2, setCount6] = useState(0)
    const [result3, setCount7] = useState(0)
    const [result4, setCount8] = useState(0)
    const [text, setText] = useState("")
    return(
        <div>
        <input type='text' onChange={(e) => setCount(parseInt(e.target.value))}></input>
        <label>{text}</label>
        <p>
        <input type='text' onChange={(e) => setCount3(parseInt(e.target.value))}></input>
        <label>{text}</label>
        <input type='text' onChange={(e) => setCount4(parseInt(e.target.value))}></input>
        <label>{text}</label></p>
        <p>
        <button onClick={() => setCount5((result1) => numero + numeroalternativo)}>
          Soma = {result1}
        </button>
        <button onClick={() => setCount6((result2) => numero - numeroalternativo)}>
          Subtração = {result2}
        </button>
        <button onClick={() => setCount7((result3) => numero * numeroalternativo)}>
          Multiplicação = {result3}
        </button>
        <button onClick={() => setCount8((result4) => numero / numeroalternativo)}>
          Divisão = {result4}
        </button></p>
        </div>
    )
}